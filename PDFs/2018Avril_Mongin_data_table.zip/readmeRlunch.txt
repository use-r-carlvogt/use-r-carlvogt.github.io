ipynb file is a jupyter file. 
I recommend jupyter to share/present code. 
You will find jupyter with winpython for windows, and with anaconda for mac and linux.

The slide show needs a copy of reveal.js file in the folder containing the presentation.
You'll find it here :https://github.com/hakimel/reveal.js.git
you can execute the command
git clone https://github.com/hakimel/reveal.js.git
in your folder