#' ---
#' title: "GSIT"
#' author: "Anne Hova"
#' date: "April 1st, 2020"
#' ---

# Depuis RStudio, il est relativement facile d'obtenir un document word contenant
# Les commandes ET les resultats (outputs et graphes)
# Seule necessite: 
# 1) Ajouter les commandes pour activer toutes les libraries utilisees par ce code
# (elles doivent deja etre telechargees). P.ex:

library(afex)

# 2) Ajouter les commandes pour importer les donnees EN SPECIFIANT EXACTEMENT LE 
# BON chemin d'acces. Le plus simple est d'utiliser les clic-clic (Import Dataset, etc)
# et de copier coller ci-dessou la commande qui en resulte dans la Console. P.ex.
# Rappel: Vos directoire et nom de fichiers ne doivent pas contenir d'accents

GSIT <- read.csv("H:/mon/chemin/acces/GSIT.csv")
# 3) Ensuite, les commandes correspondant a votre analyse
# 4) Cliquer File > Compile report  et choisir MSWord (la 1ere fois, il faut accepter l'installation des packages).


# Boxplot
boxplot( Score ~ Group, data = GSIT, xlab = "Groupe d’âge",
         ylab = "Global Symptom Index T score", col = "gray")

# ANOVA
monanova <- aov_car( Score ~ Group + Error(ID), data = GSIT)

# Table d'ANOVA
summary( monanova$aov)

# PS1 : Après avoir selection File > Compile report, cliquez sur le lien disponible.
#       Il vous dirige vers la page web contenant à la documentation permettant de 
#       personaliser votre rapport MSWord. Ajoutez un titre, et un nom d'auteur.

