# Ex 1: Retrieving base maps from Google with gmap function in package dismo
install.packages("raster")
library(raster)
library(Rcpp)
install.packages("rgdal")
library(rgdal)
install.packages("dismo")
library(dismo)
install.packages("XML")
library(XML)
mymap <- gmap('Switerland')  # choose whatever country
plot(mymap)
mymap <- gmap('Wallis, Switzerland', type='satellite')
plot(mymap)


# Ex 2: RWorldMap: mapping global data 

install.packages("rworldmap"); library(rworldmap)

newmap <- getMap(resolution = "coarse")  # different resolutions available
plot(newmap)

data("countryExData",envir=environment(),package="rworldmap")
sPDF <- joinCountryData2Map(countryExData, joinCode = "ISO3", nameJoinColumn = "ISO3V10")
mapCountryData(sPDF, nameColumnToPlot="BIODIVERSITY")


# Ex 3: Example dataset: retrieve point occurrence data from GBIF

library(dismo)
install.packages("jsonlite")
library(jsonlite)

laurus <- gbif("Laurus", "nobilis")# get data frame with spatial coordinates (points)
locs <- subset(laurus, select = c("country", "lat", "lon"))
head(locs)  # a simple data frame with coordinates

# Discard data with errors in coordinates:
locs <- subset(locs, locs$lat < 90)

# Making data 'spatial???
coordinates(locs) <- c("lon", "lat")  # set spatial coordinates
plot(locs)
# Define spatial projection (http://www.spatialreference.org/)
crs.geo <- CRS("+proj=longlat +ellps=WGS84 +datum=WGS84")  
# geographical, datum WGS84
proj4string(locs) <- crs.geo  
# define projection system of our datasummary(locs)

# Quickly plotting point data on a map
library(rworldmap) 
# library rworldmap provides different types of global maps, e.g:data(coastsCoarse)
plot(coastsCoarse)
data(countriesLow)
plot(countriesLow)
points(locs, pch = 20, col = "steelblue")

# Subsetting and mapping again
locs.gb <- subset(locs, locs$country == "United Kingdom")  
# select only locs in UK
plot(locs.gb, pch = 20, cex = 2, col = "steelblue")
title("Laurus nobilis occurrences in UK")
plot(countriesLow, add = T)


# Ex 4: Mapping vectorial data (points, polygons, polylines)
gbmap <- gmap(locs.gb, type = "satellite")
locs.gb.merc <- Mercator(locs.gb)  
# Google Maps are in Mercator projection. # This function projects the points to that projection to enable mapping
plot(gbmap)
points(locs.gb.merc, pch = 20, col = "red")

# Projecting shapefile of countries
plot(countriesLow)  # countries map in geographical projection
crs.laea <- CRS("+proj=laea +lat_0=52 +lon_0=10 +x_0=4321000 +y_0=3210000 +ellps=GRS80 +units=m +no_defs")  
# Lambert Azimuthal Equal Area
country.laea <- spTransform(countriesLow, crs.laea) 
# project
plot(country.laea)



# Ex 5: Downloading raster climate data from internet
library(dismo)
tmin <- getData("worldclim", var = "tmin", res = 10)  
# this will download 

# Loading a raster layer
tmin1 <- raster(paste(getwd(), "/wc10/tmin1.bil", sep = ""))  # Tmin for January
tmin1 <- tmin1/10  # Worldclim temperature data come in decimal degrees 
tmin1  

# look at the info# global data on minimum temperature at 10' resolution
plot(tmin1)

# Ex 6: Creating a raster stack
# A raster stack is collection of many raster layers with the same projection, spatial extent and resolution. Let's collect several raster files from disk and read them as a single raster stack:

install.packages("gtools")
library(gtools)
file.remove(paste(getwd(), "/wc10/", "tmin_10m_bil.zip", sep = ""))
list.ras <- mixedsort(list.files(paste(getwd(), "/wc10/", sep = ""), full.names = T,                                  pattern = ".bil"))

list.ras  # a list of the files containing monthly temperature values
tmin.all <- stack(list.ras)
tmin.all
tmin.all <- tmin.all/10
plot(tmin.all)


# Ex 7: Crop rasters
plot(tmin1)
newext <- drawExtent()  
# click twice on the map to select the region of interest

tmin1.c <- crop(tmin1, newext)
plot(tmin1.c)

# Alternatively, provide coordinates for the limits of the region of interest:  
newext <- c(-10, 10, 30, 50)
tmin1.c <- crop(tmin1, newext)
plot(tmin1.c)
tmin.all.c <- crop(tmin.all, newext)
plot(tmin.all.c)


# Ex 8: Define spatial projection of the rasters
crs.geo  # defined above
projection(tmin1.c) <- crs.geo
projection(tmin.all.c) <- crs.geo
tmin1.c  # notice info at coord.ref.

# Changing projection
tmin1.proj <- projectRaster(tmin1.c, crs = "+proj=merc +lon_0=0 +k=1 +x_0=0 +y_0=0 +a=6378137 +b=6378137 +units=m +no_defs")  
# can also use a template raster, see ?projectRaster
tmin1.proj  # notice info at coord.ref.
plot(tmin1.proj)

# Plotting raster data
hist(tmin1.c)
pairs(tmin.all.c)

# Ex 9: Map your won data
require(rgdal)
install.packages("ggplot2")
require(ggplot2)
install.packages("rgeos")
require(rgeos)
install.packages("ggmap")
require(ggmap)
install.packages("RColorBrewer")
require(RColorBrewer)

# Read shapefile using OGR
setwd("../spatial/GIS")
shp1 = "wsrhone.shp"
myshp1 = readOGR(shp1, layer = "wsrhone") 
shp2 = "RhoneRivers.shp"
myshp2 = readOGR(shp2, layer = "RhoneRivers") 

# Convert to lat long
myshp1_proj = spTransform(myshp1, CRS("+proj=longlat +datum=WGS84"))
myshp2_proj = spTransform(myshp2, CRS("+proj=longlat +datum=WGS84"))


# Find polygon centroid (This centers the map)
centroid = gCentroid(myshp1_proj)

# Get the Google basemap
mapImageData1 = get_map(location = c(lon = centroid$x, lat = centroid$y),                        color = "color", source = "google", maptype = "satellite", zoom = 8)

mapImageData2 = get_map(location = c(lon = centroid$x, lat = centroid$y),                        color = "color", source = "google", maptype = "roadmap", zoom = 9)

# maptypes are ???roadmap???, ???terrain???, ???satellite???, ???hybrid???

# Convert shapefile to format ggmap can work with
polys1 = fortify(myshp1_proj)
polys2 = fortify(myshp2_proj)

# Define the color scheme for mapping shp
colors = brewer.pal(9, "OrRd")

# create a first map with your data
ggmap(mapImageData1) +
  geom_polygon(aes(x = long, y = lat, group = group), data = polys1, color = colors[9], fill = colors[6], alpha = 0.5) +
  geom_polygon(aes(x = long, y = lat, group = group), data = polys2, color = "blue", alpha = 0.5) +
  labs(x = "Longitude", y = "Latitude")


# create another map
ggmap(mapImageData2) +
  geom_polygon(aes(x = long, y = lat, group = group), data = polys2, color = "blue", alpha = 0.5)+
  labs(x = "Longitude", y = "Latitude") 


