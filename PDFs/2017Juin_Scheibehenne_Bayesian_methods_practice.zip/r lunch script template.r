library(BayesFactor)

#for an overview of the package see 
#http://bayesfactorpcl.r-forge.r-project.org/


#-------------------
#example with ttests

  #Data: 
  # t(79)=2.03; 
  
  #frequentist p-value 
  1-pt(2.03, df=79)

  #reverse-engineer BF from frequentist t-test using ttest.tstat()
  #Note: calculations based on JZS prior; set simple = True to obtain BF directly
  bf =

  
  #calculate dependent t-test based on simulated data using ttestBF()
  set.seed(1234)
  x=rnorm(30, mean=.8, sd=1)
  hist(x, col="lightblue", breaks=10)
  
  #frequentist t-test
  t.test(x, mu =0)
  
  #bayesian t-test
  bf=
  
  
  #test directed hypothesis that x>0 by defining a nullInterval between 0 and Inf
  t.test(x, mu =0, alternative = "greater")
  
  bf=
  

  #change prior concentration parameter (interpret as prior on effect size)
  bf=
 
  
#-------------------------- 
#example with binomial data
  
  #data: choice behavior of a gorilla at the zoo in Basel...
  quarta=c(green=18,blue=7 )
  
  
  #calculate frequentist binomial test using prop.test() (H0 = no color preference)
  prop.test(x=quarta["green"], n=sum(quarta), p=.5)
  
  
  # Calculate Bayesian binomial test using proportionBF()
  bf =
  
  
#----------------------- 
#example with 2x2 tables
  
  #Data from towel-reuse experiment by Goldstein et al. 
  data=rbind(control=c(reuse=74,throw=137),
             socialnorm=c(reuse=98,throw=124))
  
  #frequentist chi2 test
  chisq.test(data, correct=F)
  
  #bayesian test using contingencyTableBF 
  #Note: define sampling plan as indepMulti and fixedMargin = rows
  bf = 
    

#-----------------------------    
#example with linear regression
  
  #Data: 
  #model1: N = 30; 1 predictor; R2 = .4
  #model2: N = 30; 2 predictors; R2 = .45
  
  #reverse engineer BF from R2 statistic using linearReg.R2stat() 
  #Note: set simple = true to obtain BF directly
  m1 =
  m2 =

  #calculate bf of model1 over model 2
  
    
  #estimate simple regression with simulated data using lmBF() 
  #Note: lmBF returns BF against null-model with intercept only
  
  library(MASS)
  sigma=rbind(c(1,.5),
              c(.5,1))
  
  set.seed(1234)
  xy=mvrnorm(n = 30, mu=c(0,0), Sigma=sigma)
  
  d=data.frame(x=xy[,1],y=xy[,2])
  
  #frequentist regression
  summary(lm(y~x, data=d))
  
  #bayesian regression
  bf=
  
  #sampling from the posterior distribution using posterior()
  #Note: sig2 = error variance; delta = effect size; g = nuisance factor
  
  chains=posterior(bf, iterations=1000)
  summary(chains)
  
  
  
#-----------------------------

#mention Jeff Rouder's website: http://pcl.missouri.edu/bayesfactor

#mention JASP